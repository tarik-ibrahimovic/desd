# Clocking

Dato `k` intero strettamente positivo, deve verificarsi che:

```
baud * 16 * k = clk_uart
```

Ad esempio, se il baud è `2e6`, i possibili clock sono:

- `32 MHz`
- `64 MHz`
- `96 MHz`
- `128 MHz`

etc...

Se questa condizione non è verificata, è probabile che non funzioni bene. La probabilità di malfunzionamento aumenta all'aumentare del baud. Se il clock è molto vicino a quello richiesto, potrebbe funzionare comunque.